
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author WIN 10
 */
public class MorphologicalParser {

    ArrayList<String> pref;
    ArrayList<String> pref1;
    ArrayList<String> pref2;
    ArrayList<String> pref3;
    ArrayList<String> pref4;
    ArrayList<String> pref5;
    ArrayList<String> pref6;
    ArrayList<String> suf;
    ArrayList<String> hasilList;
    ArrayList<String> inf;
    ArrayList[] preArr;

    String hasilTanpaAkhiran = "";

    public MorphologicalParser(ArrayList<String> pref, ArrayList<String> suf, ArrayList<String> inf) {
        this.pref = pref;
        this.suf = suf;
        pref.sort(new StringComparator());
        Collections.reverse(pref);
        suf.sort(new StringComparator());
        Collections.reverse(suf);
        hasilList = new ArrayList<>();
        this.inf = inf;
    }

    public MorphologicalParser(ArrayList[] preArr, ArrayList<String> suf, ArrayList<String> inf) {
        this.preArr = preArr;
        this.suf = suf;
        this.pref1 = preArr[0];
        this.pref2 = preArr[1];
        this.pref3 = preArr[2];
        this.pref4 = preArr[3];
        this.pref5 = preArr[4];
        this.pref6 = preArr[5];
        this.inf = inf;
        suf.sort(new StringComparator());
        Collections.reverse(suf);
        pref1.sort(new StringComparator());
        Collections.reverse(pref1);
        pref2.sort(new StringComparator());
        Collections.reverse(pref2);
        pref3.sort(new StringComparator());
        Collections.reverse(pref3);
        pref4.sort(new StringComparator());
        Collections.reverse(pref4);
        pref5.sort(new StringComparator());
        Collections.reverse(pref5);
        pref6.sort(new StringComparator());
        Collections.reverse(pref6);
        hasilList = new ArrayList<>();
    }

    public boolean isVokal(char in) {
        if (in == 'a' || in == 'e' || in == 'i' || in == 'u' || in == 'o') {
            return true;
        }
        return false;

    }

    /**
     * Buat ngecek lexicon biar ga harus nulis Trie.blablabla
     *
     * @param s inputnya
     * @return kalo true berarti di lexicon ada sm di hasilListnya belum ada yg
     * sama
     */
    private boolean cekLexicon(String s) {
        return (Trie.getInstance().search(s) && !hasilList.contains(s));
    }

    public ArrayList<String> cekBerimbuhan(String input, int count) {
        boolean ketemu = false;
        hasilList.clear();
        String in = input;
        String prefix = "";

        String prefixTemp = "";
        String prefixTemp2 = "";
        String wordParse = "";
        String hasil = "";

        int counter = count;

        String infix = "";
        String suffix = "";

        ArrayList<String> prefixList = new ArrayList<>();

        //kalo misalnya kata tersebut udh kata dasar
        if (Trie.getInstance().search(in)) {
            hasilList.add(in);
            //return hasilList;
        }
        for (int i = 0; i < in.length(); i++) {
            hasil += in.substring(i, i + 1);
            /**
             * Cek prefiksnya dari string hasil
             */
            if (i == 0) {
                if (hasil.equals(pref1.get(0))) {
                    //prefix = pref1.get(0);
                    prefixList.add(pref1.get(0));
                }
            }
            if (i == 1) {
                for (int j = 0; j < pref2.size(); j++) {
                    if (hasil.equals(pref2.get(j))) {
                        prefixList.add(pref2.get(j));
                        break;
                    }
                }
            }
            if (i == 2) {
                for (int j = 0; j < pref3.size(); j++) {
                    if (hasil.equals(pref3.get(j))) {
                        prefixList.add(pref3.get(j));
                        break;
                    }
                }
            }
            if (i == 3) {
                for (int j = 0; j < pref4.size(); j++) {
                    if (hasil.equals(pref4.get(j))) {
                        prefixList.add(pref4.get(j));
                        break;
                    }
                }
            }
            if (i == 4) {
                for (int j = 0; j < pref5.size(); j++) {
                    if (hasil.equals(pref5.get(j))) {
                        prefixList.add(pref5.get(j));
                        break;
                    }
                }
            }
            if (i == 5) {
                for (int j = 0; j < pref6.size(); j++) {
                    if (hasil.equals(pref6.get(j))) {
                        prefixList.add(pref6.get(j));
                        break;
                    }
                }
            }

        }

        for (int i = 0; i < prefixList.size(); i++) {
            String temp;
            if (prefixList.get(i).length() == 1) {
                temp = hasil.substring(1); //BELUM NGECEK SUFIKS. KALO SUFIKS UDAH MASUK TOLONG GANTI UPPERBOUNDNYA
                if (cekLexicon(temp)) {
                    if (Trie.hasilKata != "") {
                        hasilList.add(Trie.hasilKata);
                    } else {
                        hasilList.add(temp);
                    }
                }
                this.cekSufiks(temp, suf);
                prefixTemp = temp;
                prefixTemp2 = hasil;

            } else if (prefixList.get(i).length() == 2) {
                temp = hasil.substring(2);
                prefixTemp = temp;
                if (temp.length() > 2) { // ini cuma supaya kalo disubstring g error
                    if (prefixList.get(i).equals("me") || prefixList.get(i).equals("pe")) {

                        if (cekLexicon(temp)) {
                            if (Trie.hasilKata != "") {
                                hasilList.add(Trie.hasilKata);
                            } else {
                                hasilList.add(temp);
                            }
                            ketemu = true;

                        } else {
                            prefixTemp = temp;
                            if (prefixList.get(i).equals("me")) {
                                prefix = "me";
                            } else {
                                prefix = "pe";
                            }
                        }
                        if (temp.substring(0, 1).equals("m")) {
                            prefix += "m";
                            if (cekLexicon(temp.substring(1))) {
                                ketemu = true;
                                if (Trie.hasilKata != "") {
                                    hasilList.add(Trie.hasilKata);
                                } else {
                                    hasilList.add(temp.substring(1));
                                }
                            } //else {
                            prefixTemp = temp.substring(1);
                            this.cekSufiks(prefixTemp, suf);
                            //}
                            String temp2 = "p" + temp.substring(1);
                            prefixTemp2 = temp2;
                            if (cekLexicon(temp2)) {
                                ketemu = true;
                                if (Trie.hasilKata != "") {
                                    hasilList.add(Trie.hasilKata);
                                } else {
                                    hasilList.add(temp2);
                                }
                            }
                            this.cekSufiks(temp2, suf);
                        }

                        if (temp.substring(0, 1).equals("n")) {
                            prefix += "n";
                            if (cekLexicon(temp.substring(1))) {
                                ketemu = true;
                                if (Trie.hasilKata != "") {
                                    hasilList.add(Trie.hasilKata);
                                } else {
                                    hasilList.add(temp.substring(1));
                                }
                            }

                            prefixTemp = temp.substring(1);
                            this.cekSufiks(prefixTemp, suf);

                            String temp2 = "t" + temp.substring(1);
                            if (cekLexicon(temp2)) {
                                ketemu = true;
                                if (Trie.hasilKata != "") {
                                    hasilList.add(Trie.hasilKata);
                                } else {
                                    hasilList.add(temp2);
                                }
                            } //else {
                            this.cekSufiks(temp2, suf);
                            prefixTemp2 = temp2;
                            //}
                        }
                        if (temp.substring(0, 2).equals("ng")) {
                            prefix += "g";

                            if (cekLexicon(temp.substring(2))) {
                                ketemu = true;
                                if (Trie.hasilKata != "") {
                                    hasilList.add(Trie.hasilKata);
                                } else {
                                    hasilList.add(temp.substring(2));
                                }
                            }

                            prefixTemp = temp.substring(2);

                            //ini kalo cuma satu suku kata
                            //harusnya kalo cuma satu suku kata si katanya paling banyak ada tiga huruf
                            if (temp.substring(2, 3).equals("e")) {
                                prefix += "e";
                                String temp2 = temp.substring(3);
                                if (cekLexicon(temp2)) {
                                    ketemu = true;
                                    if (Trie.hasilKata != "") {
                                        hasilList.add(Trie.hasilKata);
                                    } else {
                                        hasilList.add(temp2);
                                    }
                                }
                                this.cekSufiks(temp2, suf);
                                prefixTemp = temp2;
                            }
                            String temp2 = "k" + temp.substring(2);
                            if (cekLexicon(temp2)) {

                                ketemu = true;
                                if (Trie.hasilKata != "") {
                                    hasilList.add(Trie.hasilKata);
                                } else {
                                    hasilList.add(temp2);
                                }
                            }
                            prefixTemp2 = temp2;
                            this.cekSufiks(temp2, suf);
                        }
                        if (temp.substring(0, 2).equals("ny")) {
                            prefix += "ny";
                            String temp2 = "s" + temp.substring(2);
                            if (cekLexicon(temp2)) {
                                ketemu = true;
                                if (Trie.hasilKata != "") {
                                    hasilList.add(Trie.hasilKata);
                                } else {
                                    hasilList.add(temp2);
                                }
                            }
                            this.cekSufiks(temp2, suf);
                            prefixTemp = temp2;
                        }
                    } else if (prefixList.get(i).equals("be") || prefixList.get(i).equals("te")) {
                        if (prefixList.get(i).equals("be")) {
                            prefix = "be";
                        } else {
                            prefix = "te";
                        }

                        if (temp.substring(0, 1).equals("r")) {
                            prefix += "r";
                            prefixTemp2 = temp;
                            if (cekLexicon(temp)) {
                                ketemu = true;
                                if (Trie.hasilKata != "") {
                                    hasilList.add(Trie.hasilKata);
                                } else {
                                    hasilList.add(temp);
                                }
                            }
                            if (cekLexicon(temp.substring(1))) {
                                ketemu = true;
                                if (Trie.hasilKata != "") {
                                    hasilList.add(Trie.hasilKata);
                                } else {
                                    hasilList.add(temp.substring(1));
                                }
                            } else {
                                prefixTemp = temp.substring(1);

                            }
                        } else {
                            if (temp.length() > 2 && temp.substring(1, 3).equals("er")) {
                                if (cekLexicon(temp.substring(3))) {
                                    ketemu = true;
                                    if (Trie.hasilKata != "") {
                                        hasilList.add(Trie.hasilKata);
                                    } else {
                                        hasilList.add(temp.substring(3));
                                    }
                                } else {
                                    prefixTemp = temp.substring(3);
                                }
                            }
                        }
                    } else {
                        if (cekLexicon(temp)) {
                            ketemu = true;
                            if (Trie.hasilKata != "") {
                                hasilList.add(Trie.hasilKata);
                            } else {
                                hasilList.add(temp);
                            }
                        }
                    }
                    // KATA KHUSUS YG DIUBAH JADI L
                    // KALO TERNYATA ADA ATURAN YG BIKIN KATA BISA BERUBAH JADI L NANTI GANTI
                    // KATA KHUSUS KAYAKNYA HARUS HARDCODE
                    if (temp.contains("lajar")) {
                        if (cekLexicon(temp)) {
                            ketemu = true;
                            if (Trie.hasilKata != "") {
                                hasilList.add(Trie.hasilKata);
                            } else {
                                hasilList.add(temp);
                            }
                        } else {
                            prefixTemp = prefixTemp.substring(1);
                        }
                    }
                    if (temp.contains("lunjur")) {
                        if (cekLexicon(temp)) {
                            ketemu = true;
                            if (Trie.hasilKata != "") {
                                hasilList.add(Trie.hasilKata);
                            } else {
                                hasilList.add(temp);
                            }
                        } else {
                            prefixTemp = prefixTemp.substring(1);
                        }
                    }
                }
                this.cekSufiks(temp, suf);
            } else if (prefixList.get(i).length() == 3) {
                temp = hasil.substring(3);
                if (temp.length() > 2) {
                    // ini kyknya ga perlu dikasih if yg ini
                    // kyknya bisa langsung cek lexicon aja
                    if (prefixList.get(i).equals("ber") || prefixList.get(i).equals("ter")) {
                        if (cekLexicon(temp)) {
                            ketemu = true;
                            if (Trie.hasilKata != "") {
                                hasilList.add(Trie.hasilKata);
                            } else {
                                hasilList.add(temp);
                            }
                        } else {
                            prefixTemp = temp;
                        }
                    } else {
                        if (cekLexicon(temp)) {
                            ketemu = true;
                            if (Trie.hasilKata != "") {
                                hasilList.add(Trie.hasilKata);
                            } else {
                                hasilList.add(temp);
                            }
                        } else {
                            prefixTemp = temp;
                        }
                    }
                }
                this.cekSufiks(temp, suf);
            } else if (prefixList.get(i).length() == 4) {
                temp = hasil.substring(4);
                if (temp.length() > 2) {
                    if (cekLexicon(temp)) {
                        prefix = hasil.substring(0, 4);
                        ketemu = true;
                        if (Trie.hasilKata != "") {
                            hasilList.add(Trie.hasilKata);
                        } else {
                            hasilList.add(temp);
                        }
                    } else {
                        prefixTemp = temp;
                    }
                }
                this.cekSufiks(temp, suf);
            } else if (prefixList.get(i).length() == 5) {
                temp = hasil.substring(5);
                if (temp.length() > 2) {
                    if (cekLexicon(temp)) {
                        ketemu = true;
                        if (Trie.hasilKata != "") {
                            hasilList.add(Trie.hasilKata);
                        } else {
                            hasilList.add(temp);
                        }
                    } else {
                        prefixTemp = temp;
                    }
                }
                this.cekSufiks(temp, suf);
            }
            if (prefixList.get(i).length() == 6) {
                temp = hasil.substring(6);
                if (temp.length() > 2) {
                    if (cekLexicon(temp)) {
                        ketemu = true;
                        if (Trie.hasilKata != "") {
                            hasilList.add(Trie.hasilKata);
                        } else {
                            hasilList.add(temp);
                        }
                    } else {
                        prefixTemp = temp;
                    }
                }
                this.cekSufiks(temp, suf);
            }
        }
        String kataUlang = "";

        if (hasilList.isEmpty()) {

            if (hasil.contains("-")) {
                Parser parser = new Parser(this);
                String[] cekDepanBelakang = hasil.split("-");
                if (cekDepanBelakang[0].length() == cekDepanBelakang[1].length()) {
                    try {
                        kataUlang = parser.cekPengulangan(hasil);
                    } catch (IOException ex) {
                        Logger.getLogger(MorphologicalParser.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    if (!kataUlang.isEmpty()) {
                        hasilList.add(kataUlang);
                        return hasilList;
                    }
                }
                this.cekSufiks(hasil, suf);

                try {
                    kataUlang = parser.cekPengulangan(hasilTanpaAkhiran);
                    System.out.println(kataUlang);
                } catch (IOException ex) {
                    Logger.getLogger(MorphologicalParser.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (!kataUlang.isEmpty()) {

                    hasilList.add(kataUlang);
                    return hasilList;
                }

                if (!prefixTemp2.isEmpty()) {

                    kataUlang = "";
                    try {
                        kataUlang = parser.cekPengulangan(prefixTemp2);
                        
                    if (!kataUlang.isEmpty()) {
                        hasilList.add(kataUlang);
                        return hasilList;
                    }

                    } catch (IOException ex) {
                        Logger.getLogger(MorphologicalParser.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    this.cekSufiks(prefixTemp2, suf);
                    kataUlang="";
                    try {
                        if(hasilTanpaAkhiran!=null){
                            kataUlang = parser.cekPengulangan(hasilTanpaAkhiran);
                        }

                    } catch (IOException ex) {
                        Logger.getLogger(MorphologicalParser.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    if (!kataUlang.isEmpty()) {
                        hasilList.add(kataUlang);
                        return hasilList;
                    }

                }
            } else {
                this.cekSufiks(hasil, suf);
            }
        }
        this.cekSufiks(in, suf);
        if (prefixTemp.length() > 0) {
            this.cekInfiks(prefixTemp);
        } else {
            this.cekInfiks(hasil);
        }
        if (hasilList.isEmpty() && counter != 2) {
            hasil = prefixTemp;
            counter++;

            hasilList = cekBerimbuhan(hasil, counter);

            if (hasilList.isEmpty()) {
                hasilList = cekBerimbuhan(prefixTemp2, counter);
            }
        }

        return hasilList;
    }

    private void cekSufiks(String s, ArrayList<String> suf) {
        this.hasilTanpaAkhiran = s;
        for (int i = 0; i < suf.size(); i++) {
            if (s.endsWith(suf.get(i))) {

                String temp = s.substring(0, s.length() - suf.get(i).length());
                if (temp.length() > 2) {
                    if (cekLexicon(temp)) {
                        hasilList.add(temp);
                    } else {
                        this.hasilTanpaAkhiran = temp;
                    }
                }
            }
        }
    }

    //inputanya itu string yg udh g ad sufix am infix sama file infiks.txt
    private void cekInfiks(String s) {

        String infix;
        if (!cekLexicon(s) && s.length() > 2) {
            //System.out.println(s);
            for (int i = 0; i < inf.size(); i++) {
                infix = inf.get(i);
                String temp = s.substring(1, 3);
                if (temp.equals(infix)) {
                    if (!isVokal(s.charAt(0))) {
                        if (isVokal(s.charAt(1))) {
                            int j = 3;
                            //while(!isVokal(s.charAt(j))){
                            //    j++;
                            //}

                            String hasilInfix = s.substring(0, 1) + s.substring(j, s.length());

                            if (cekLexicon(hasilInfix)) {
                                //String hasilInfix = s.substring(0,j);
                                //String belakang=s.substring(j+1,s.length());
                                hasilList.add(hasilInfix);
                            }
                        }
                    }
                }
            }
        }
    }
}

class StringComparator implements Comparator<String> {

    @Override
    public int compare(String o1, String o2) {
        return Integer.compare(o1.length(), o2.length());
    }
}
